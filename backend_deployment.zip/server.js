const app = require('./app');

try {
  const { validateDatabaseEnv } = require('./config/validateEnv');
  validateDatabaseEnv();
} catch (err) {
  console.warn('[WARNING] Env validation warning:', err.message);
}

const PORT = process.env.PORT || 3000;

if (typeof PhusionPassenger !== 'undefined') {
  app.listen('passenger');
} else {
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

module.exports = app;

